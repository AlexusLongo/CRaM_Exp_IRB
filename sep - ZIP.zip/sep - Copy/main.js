//document.write("Welcome!")
// 1 sec Test button
//const buttonT = document.createElement("button")
//buttonT.innerText = "Click for 1s test"
//document.body.appendChild(buttonT)
//buttonT.addEventListener('click', () => {
  // setTimeout uses msec; if you put it outside the click, it runs by itself
  //var oneSec = 1000;
  //setTimeout(function(){
    //document.write("Hello")
  //}, oneSec)
//})
// Instructions button
//const button = document.createElement("button")
//button.innerText = "Click for Instructions"
//document.body.appendChild(button)

//function instruPage() {
  //document.write("Instructions go here.")
//}
//button.addEventListener('click', instruPage)
///////
// Get experiment popup
  //const buttonB = document.createElement("button")
  //buttonB.innerText = "Click to begin..."
  //buttonB.addEventListener('click', () => {
    //alert("Experiment goes here")
  //}
//)
  //document.body.appendChild(buttonB)
//}
//button.addEventListener('click', instruPage)
